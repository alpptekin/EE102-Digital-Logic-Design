import cv2
import mediapipe as mp
import serial
import time
import math

class HandGestureController:
    def __init__(self, serial_port='COM3', baud_rate=9600):
        """
        Initializes the Hand Gesture Controller.
        Adjust 'serial_port' to match your FPGA connection (e.g., 'COM3' on Windows, '/dev/ttyUSB0' on Linux).
        """
        self.ser = None
        try:
            self.ser = serial.Serial(
                port=serial_port,
                baudrate=baud_rate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=1
            )
            print(f"[SUCCESS] Serial connected on {serial_port}")
        except serial.SerialException as e:
            print(f"[WARNING] Serial not connected: {e}")
            print("[INFO] Running in Simulation Mode (No UART output)")

        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=1,          # We only want to track one hand
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        self.mp_draw = mp.solutions.drawing_utils

        self.confirmation_time = 2.0  # Seconds to hold gesture
        self.current_number = 0
        self.last_number = -1
        self.start_time = 0
        self.data_sent = False        # Lock to prevent spamming UART
        
        # UI Colors (B, G, R)
        self.COLOR_DEFAULT = (255, 0, 0)   # Blue
        self.COLOR_WAITING = (0, 255, 255) # Yellow
        self.COLOR_SUCCESS = (0, 255, 0)   # Green

    def count_fingers(self, landmarks, handedness_label):
        """
        Counts extended fingers based on landmark coordinates.
        Logic is optimized for the RIGHT HAND.
        """
        fingers = []
        
        # Landmark Indices
        # Thumb: 4, Index: 8, Middle: 12, Ring: 16, Pinky: 20
        tips = [4, 8, 12, 16, 20]
        

        if handedness_label == 'Right':
            if landmarks[tips[0]].x < landmarks[tips[0] - 1].x:
                fingers.append(1)
            else:
                fingers.append(0)
        else:
            if landmarks[tips[0]].x > landmarks[tips[0] - 1].x:
                fingers.append(1)
            else:
                fingers.append(0)


        for id in range(1, 5):
            if landmarks[tips[id]].y < landmarks[tips[id] - 2].y:
                fingers.append(1)
            else:
                fingers.append(0)

        return fingers.count(1)

    def send_to_fpga(self, number):
        """Sends the detected number to FPGA via UART."""
        if self.ser and self.ser.is_open:
            try:
                data = str(number).encode('utf-8')
                self.ser.write(data)
                print(f"[UART] Sent: {data}")
                return True
            except Exception as e:
                print(f"[ERROR] UART Write Failed: {e}")
        return False

    def run(self):
        cap = cv2.VideoCapture(0)
        window_name = "Right Hand Gesture -> UART"
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, 1280, 720)
        while True:
            success, img = cap.read()
            if not success:
                break

            img = cv2.flip(img, 1)
            
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            results = self.hands.process(img_rgb)

            detected_count = 0
            hand_label = "None"

            if results.multi_hand_landmarks:
                for hand_lms, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):

                    hand_label = handedness.classification[0].label

                    self.mp_draw.draw_landmarks(img, hand_lms, self.mp_hands.HAND_CONNECTIONS)
                    

                    if hand_label == 'Right':
                        lm_list = hand_lms.landmark
                        detected_count = self.count_fingers(lm_list, hand_label)
                    else:
                        cv2.putText(img, "Please use Right Hand", (50, 50), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

            
            if 1 <= detected_count <= 5:
                if detected_count == self.last_number:
                    elapsed_time = time.time() - self.start_time
                    
                    if elapsed_time >= self.confirmation_time:
                        progress = 1.0
                        if not self.data_sent:

                            self.send_to_fpga(detected_count)
                            self.data_sent = True 
                    else:
                        progress = elapsed_time / self.confirmation_time
                else:
                    # Number changed (reset logic)
                    self.last_number = detected_count
                    self.start_time = time.time()
                    progress = 0.0
                    self.data_sent = False
            else:

                self.last_number = -1
                progress = 0.0
                self.data_sent = False


            h, w, c = img.shape
            

            bar_x = 30
            bar_y = h - 40 
            bar_w = 300       
            bar_h = 15       

            cv2.rectangle(img, (bar_x, bar_y), (bar_x + bar_w, bar_y + bar_h), (50, 50, 50), 2)
            

            current_bar_w = int(bar_w * progress)
            

            bar_color = self.COLOR_WAITING if progress < 1.0 else self.COLOR_SUCCESS
            

            if detected_count > 0:
                cv2.rectangle(img, (bar_x, bar_y), (bar_x + current_bar_w, bar_y + bar_h), bar_color, cv2.FILLED)


            cv2.putText(img, f'Detected: {detected_count}', (bar_x, bar_y - 15), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)


            if self.data_sent:
                 cv2.putText(img, f'[SENT TO FPGA: {detected_count}]', (bar_x, bar_y - 60), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, self.COLOR_SUCCESS, 2)

            cv2.imshow(window_name, img)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break


        cap.release()
        cv2.destroyAllWindows()
        if self.ser:
            self.ser.close()
if __name__ == "__main__":
    app = HandGestureController(serial_port='COM7', baud_rate=9600)
    app.run()